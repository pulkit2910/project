import React from "react";
import Register from './Register';
import SignIn from './SignIn'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

export default class Home extends React.Component {
    
        render() {
          return (
          <Router>
              <div>
                <h2>Welcome Login APP</h2>
                <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <ul className="navbar-nav mr-auto">
                    <h3><li><Link to={'/Register'} className="nav-link">Register</Link></li></h3>
                    <h3><li><Link to={'/SignIn'} className="nav-link">SignIn</Link></li></h3>
                </ul>
                </nav>
                <hr />
                <Switch>
                    <Route exact path='/' component={Register} />
                    <Route path='/Register' component={Register} />
                    <Route path='/SignIn' component={SignIn} />
                </Switch>
              </div>
            </Router>
          );
        }
      }