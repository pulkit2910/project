import React from "react";
import "./Display.css";

  
  export default class SignIn extends React.Component {
    message;
    constructor() {
      super();
      this.state = {
        email: '',
        password: '',
        
        touched: {
          email: false,
          password: false,
        },
      };
    }

    handleEmailChange = (evt) => {
      this.setState({ email: evt.target.value });
    }
        
    handlePasswordChange = (evt) => {
      this.setState({ password: evt.target.value });
    }
    
    handleBlur = (field) => (evt) => {
      this.setState({
        touched: { ...this.state.touched, [field]: true },
      });
    }

    validate = (email, username, password)=> {
      // true means invalid, so our conditions got reversed
      return {
        email: email.length === 0, //true if email is empty
        password: password.length === 0, //true if password is empty
      };
    }
    
    handleSubmit = (evt) => {
      if (!this.canBeSubmitted()) {
        evt.preventDefault();
        let email = this.getCookie("email");
        let userName = this.getCookie("username");
        let password = this.getCookie("password");

        if(email === this.state.email && password === this.state.password)
        {
            alert("Hello"+ userName + "Login Successfully");
        }
        else{
            alert("Invalid Credential or Switch to Register Page");
        }
        return;
      }

    }

    
    getCookie=(cname)=> {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    componentDidMount(){
        this.checkCookie();
    }

     checkCookie=()=> {
      var user= this.getCookie("username");
      if (user !== "") {
        alert("Welcome again " + user);
      } 
    }
    
    canBeSubmitted() {
      const errors = this.validate(this.state.email, this.state.password);
      const isDisabled = Object.keys(errors).some(x => errors[x]);
      return isDisabled;
    }
    
    render() {
      const errors = this.validate(this.state.email, this.state.username, this.state.password);
      const isDisabled = Object.keys(errors).some(x => errors[x]);
      
      const shouldMarkError = (field) => {
        const hasError = errors[field];
        const shouldShow = this.state.touched[field];
        
        return hasError ? shouldShow : false;
        
      };

      let view = (<form onSubmit={this.handleSubmit}>
         <h1>SignIn Page</h1>
         <input
          className={shouldMarkError('email') ? "error" : ""}
          type="text"
          placeholder="Enter email"
          value={this.state.email}
          onChange={this.handleEmailChange}
          onBlur={this.handleBlur('email')}
        />
        <span className={shouldMarkError('email') ? "error" : "hidden"}
        >invalid email</span>
        
        <input
          className={shouldMarkError('password') ? "error" : ""}
          type="password"
          placeholder="Enter password"
          value={this.state.password}
          onChange={this.handlePasswordChange}
          onBlur={this.handleBlur('password')}
        />
        <span className={shouldMarkError('password') ? "error" : "hidden"}
        >invalid password</span>
        
        <button disabled={isDisabled}>Sign In</button>
      </form>);
      
      
      return (
        <div>
          {view}
        </div>
      )
    }
  }
  