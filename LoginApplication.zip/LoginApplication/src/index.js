import React from "react";
import ReactDOM from "react-dom";
import Home from "./component/Home";
import "./index.css";

ReactDOM.render(<Home />, document.getElementById("root"));
